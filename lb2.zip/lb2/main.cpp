#include "application.h"

int main()
{
    Application a;
    a.exec();
    return 0;
}
