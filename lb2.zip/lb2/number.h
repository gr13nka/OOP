#ifndef NUMBER_H
#define NUMBER_H
#include "complex.h"

typedef complex number;
#endif // NUMBER_H
