#include "application.h"

int main()
{
    Application a;
    int aga = a.exec();
    return aga;
}
