#ifndef NUMBER_H
#define NUMBER_H
typedef double number;
#endif // NUMBER_H
